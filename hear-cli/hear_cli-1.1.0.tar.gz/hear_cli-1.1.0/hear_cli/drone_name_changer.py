
import os
import re
import sys
from pathlib import Path

def setdronename(drone_name,ws_abb):

    # create local tmp folder
    # create_tmp_directory()

    home = str(Path.home())
    remoteLaunchFileDir = os.path.dirname(f"{home}/HEAR_{ws_abb}/src/HEAR_{ws_abb}/Flight_controller/launch")
    # remoteLaunchFileDir = f"hear_cli/HEAR_{ws_abb}/Flight_controller/launch"

    # read launch files
    for root, dirs, files in os.walk(remoteLaunchFileDir):
        for file in files:
            if os.path.splitext(file)[1] == ".launch":

                print(os.path.join(root, file))
                localLaunchFilePath = os.path.join(root, file)
                drone_name = drone_name
                fileContents = open(localLaunchFilePath, "r").read()

                # find and erplace drone_name value
                matches = re.findall('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', fileContents)

                if len(matches) > 0:
                    # print(matches)
                    rplce = re.sub('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', f'<arg name="DRONE_NAME" value="{drone_name}"', fileContents)
                    # print(f'<arg name="DRONE_NAME" value="{drone_name}"/>')

                else:
                    # print(matches)
                    rplce = re.sub('<arg name="[DRONE_NAME\"]*"\s*', f'<arg name="DRONE_NAME" value="{drone_name}"', fileContents)
                    # print(f'<arg name="DRONE_NAME" value="{drone_name}"/>')

                checkMatches = re.findall('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', fileContents)
                print(checkMatches)




                # save replaced file locally
                with open(localLaunchFilePath, "w") as wfile:
                    wfile.write(rplce)


if __name__ == '__main__':
    drone_name = sys.argv[1] #"instance_name2"
    ws_abb = sys.argv[2] #"FC"
    print(drone_name)
    print(ws_abb)
    setdronename(drone_name,ws_abb)



