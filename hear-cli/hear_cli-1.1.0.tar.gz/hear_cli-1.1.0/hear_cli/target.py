import typer
from typing_extensions import Annotated
from PyInquirer import prompt, print_json, Separator
from enum import Enum
import json
import subprocess
from rich.prompt import Confirm
import hear_cli.docker  as docker

from enum import Enum
import hear_cli.data as data
import hear_cli.utils as utils
import sys
app = typer.Typer(
    help="All HEAR Targets managements",
    rich_markup_mode="rich",
    epilog="Made with :heart:  by [bold blue]Hashim[/bold blue] [bold green]@ DroneLeaf[/bold green]",
)
app.add_typer(docker.app, name="docker")





@app.command("init")
def init():
    """
    [bold violet]Make a full installation of all prerequisites and dependencies needs to start your workspace[/bold violet] :boom:  :boom: :sparkles:

    """
    target = ""

    if utils.isTargetSeted(data.TargetConfigKeys.init_target.name):
        target = utils.getTarget(data.TargetConfigKeys.init_target.name)
        print(target)

    else:

        target = utils.chooseTarget()

        utils.saveTarget(target,data.TargetConfigKeys.init_target.name)

    

    print(target)
    if target == data.Targets.ORIN.name:
        checkUploadConfirm = Confirm.ask(
            ":star2: Are you sure you want to make full system installation on ORIN target? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        subprocess.run(f"sudo chmod -R +x src/targets/ORIN_UBUNTU20", shell=True)
        subprocess.run(
            [
                "bash",
                "-c",
                "pushd src/targets/ORIN_UBUNTU20; ./full_system_installation.sh; popd",
            ]
        )
    elif target == data.Targets.RPI.name:
        checkUploadConfirm = Confirm.ask(
            ":star2: Are you sure you want to make full system installation on RPI target? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        subprocess.run(f"sudo chmod -R +x src/targets/RPI_UBUNTU20", shell=True)
        subprocess.run(
            [
                "bash",
                "-c",
                "pushd src/targets/RPI_UBUNTU20; ./full_system_installation.sh; popd",
            ]
        )

    elif target == data.Targets.SITL.name:
        checkUploadConfirm = Confirm.ask(
            ":star2: Are you sure you want to make full system installation on SITL target? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        subprocess.run(f"sudo chmod -R +x src/targets/SITL_UBUNTU20", shell=True)
        subprocess.run(
            [
                "bash",
                "-c",
                "pushd src/targets/SITL_UBUNTU20; ./full_system_installation.sh; popd",
            ]
        )
    else:
        sys.exit("Error happened, please refer this to hashim")


@app.command("configure")
def configure():
    """
    [bold violet]Update current command saved arguments that already been set[/bold violet] :boom:  :boom: :sparkles:

    """

    config_need = ""
    specific_config_need = ""
    config_need = utils.chooseConfigureCommand()

    if config_need == data.configure_choicesKeys['Set all configs'].name:
        set_init_target(True)
        print(config_need)
    elif config_need == data.configure_choicesKeys['Set specific config'].name:
        print(config_need)
        specific_config_need = utils.chooseTargetConfigureSpecificCommand()
        if specific_config_need == data.ConfigKeys.init_target.name:
            set_init_target(True)


def set_init_target(mandatory=False):
    if (mandatory is False) and utils.isTargetSeted(data.TargetConfigKeys.init_target.name):
        target = utils.getTarget(data.TargetConfigKeys.init_target.name)
        print(target)

    else:

        target = utils.chooseTarget()

        utils.saveTarget(target,data.TargetConfigKeys.init_target.name)


@app.callback()
def callback():
    pass


if __name__ == "__main__":
    app()
