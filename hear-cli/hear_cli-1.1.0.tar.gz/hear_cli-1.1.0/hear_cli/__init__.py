from hear_cli.main import app

app()