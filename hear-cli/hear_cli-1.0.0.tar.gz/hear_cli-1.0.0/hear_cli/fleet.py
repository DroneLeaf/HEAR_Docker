import typer
from typing_extensions import Annotated
from PyInquirer import prompt, print_json, Separator
from enum import Enum
import json
import subprocess
from subprocess import Popen, PIPE
from rich import print as rprint

from rich.prompt import Confirm
from rich.prompt import Prompt
import os

import hear_cli.data as data
import hear_cli.utils as utils
import time
import logging
import threading
import re
import socket

app = typer.Typer(help="[bold violet]update compiled files, update ROS_MASTER_URI, and drone_name launch arg  [/bold violet] [bold green]on all hear_configurtions drones [/bold green] :boom:  :boom: :sparkles:",rich_markup_mode="rich",epilog="Made with :heart:  by [bold blue]Hashim[/bold blue]")

targetsData = []


def isTargetReachable(ip):
    ClientSocket = socket.socket()
    ClientSocket.settimeout(5)
    try:
        ClientSocket.connect((ip, 22))
        ClientSocket.close()
        return True

        # port = 22
    except socket.error:
        ClientSocket.close()
        return False


# @app.command("cloneConfigurations")
def cloneConfigurations():
    # create local tmp folder
    create_tmp_directory()

    # clone HEAR_Configurations
    if os.path.isdir("tmp/HEAR_Configurations"):
        tmp = subprocess.run(
            [
                "bash",
                "-c",
                "cd tmp/HEAR_Configurations && git pull"
            ], stdout=subprocess.PIPE
        )

    else:
        tmp = subprocess.run(
            [
                "bash",
                "-c",
                "git clone -b devel https://github.com/HazemElrefaei/HEAR_Configurations.git tmp/HEAR_Configurations "
            ], stdout=subprocess.PIPE
        )

def aggrgateTargetsData():
    # aggregate targets data

    UAV_instances = os.listdir("tmp/HEAR_Configurations/UAV_instances")
    # print(UAV_instances)
    for instance in UAV_instances:
        # print(instance)
        if os.path.isdir(f'tmp/HEAR_Configurations/UAV_instances/{instance}'):
            instanceGeneral = utils.readFile(f'tmp/HEAR_Configurations/UAV_instances/{instance}/general.json')
            instanceGeneralJson = json.loads(instanceGeneral)
            ip = instanceGeneralJson['ip']
            uav_type = instanceGeneralJson['uav_type']
            typeGeneral =  utils.readFile(f'tmp/HEAR_Configurations/UAV_types/{uav_type}/general.json')
            typeGeneralJson = json.loads(typeGeneral)
            targetName = typeGeneralJson['running_target']
            # print(ip)
            # print(targetName)
            if ip != '0.0.0.0':
                targetObj={"ip":ip,"username":"pi","password":"raspberry","ROS_MASTER_URI":ip,"drone_name":instance,"HEAR_FC":True,"HEAR_MC":True}

                if targetName == "RPI_UBUNTU20":
                    targetObj["username"]= "pi"
                    targetObj["password"]= "raspberry"

                elif targetName == "ORIN_UBUNTU20":
                    targetObj["username"]= "orin"
                    targetObj["password"]= "orin"

                targetsData.append(targetObj)


    # print(targetsData)
def create_tmp_directory():
    if os.path.isdir("tmp") is False:

        tmp = subprocess.run(
            [
                "bash",
                "-c",
                "mkdir tmp "
            ], stdout=subprocess.PIPE
        )


@app.command("fleet")
def fleet():
    """
    [bold violet]update compiled files, update ROS_MASTER_URI, and drone_name launch arg  [/bold violet] [bold green]on all hear_configurtions drones [/bold green] :boom:  :boom: :sparkles:

    """
    ws_name = utils.chooseDevWsName()
    ws_abb = ''
    if ws_name == data.Workspaces.HEAR_FC.name:
        ws_abb = "FC"
    else:
        ws_abb = "MC"


    cloneConfigurations()
    aggrgateTargetsData()

    subprocess.run(
        [
            "bash",
            "-c",
            'sudo apt install sshpass -y'
        ]
    )

    #targets=[{"ip":"192.168.1.21","username":"pi","password":"raspberry","ROS_MASTER_URI":"192.168.1.21","drone_name":"UAV_1","HEAR_FC":True,"HEAR_MC":True}]





    ## get list of ips

    for target in targetsData:


        target_ip = target['ip']
        ROS_MASTER_URI = target['ROS_MASTER_URI']
        targetPass = target['password']
        target_username = target['username']
        localLaunchFileName = f"flight_controller.launch"
        localLaunchFileDir = f"tmp"
        remoteLaunchFileDir = f"~/HEAR_{ws_abb}/src/HEAR_{ws_abb}/Flight_controller/launch"
        localLaunchFilePath = f"{localLaunchFileDir}/{target_ip}_{localLaunchFileName}"
        drone_name = target['drone_name']

        if isTargetReachable(target_ip):

            # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
            p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

            def read_stdout():
                for line in iter(p.stdout.readline, ''):
                    print(line, end='')

            def read_stderr():
                for line in iter(p.stderr.readline, ''):
                    print(line, end='')



            con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

            p.stdin.write(con1)
            p.stdin.flush()


            ## all commands
            replaceCommand = f"if grep -q ROS_MASTER_URI .bashrc; then sed -i 's/^\(ROS_MASTER_URI\s*=\s*\).*$/\ROS_MASTER_URI={ROS_MASTER_URI}/' .bashrc && source ~/.bashrc; else echo 'ROS_MASTER_URI={ROS_MASTER_URI}' >> ~/.bashrc && source ~/.bashrc ; fi\n".encode()
            packagesInstall = f'echo {targetPass} | sudo -S apt install unzip wget -y\n'.encode()
            compiledZippedDownload = f'wget https://hear-bucket.s3.me-south-1.amazonaws.com/hear_arch/hear_{ws_abb.lower()}_devel.zip -O hear_fc_devel_compiled.zip \n'.encode()
            unzipFile = f'unzip -o hear_{ws_abb.lower()}_devel_compiled.zip -d hear_{ws_abb.lower()}_devel_compiled\n'.encode()

            cpFolder = f'cp -rf  hear_{ws_abb.lower()}_devel_compiled/compiled_files ~/HEAR_{ws_abb}\n'.encode()
            exit = b'exit\n'


            commands = [replaceCommand,packagesInstall,compiledZippedDownload,unzipFile,cpFolder,exit]

            # Execute each command and print the output in real-time
            # Start threads to continuously read from stdout and stderr
            stdout_thread = threading.Thread(target=read_stdout)
            stderr_thread = threading.Thread(target=read_stderr)
            stdout_thread.start()
            stderr_thread.start()

            # Execute each command and write to stdin
            for command in commands:
                p.stdin.write(command.decode() + "\n")
                p.stdin.flush()

            # Close stdin to signal the end of input
            p.stdin.close()

            # Wait for the subprocess to finish
            p.wait()

            # Join the threads to wait for them to complete
            stdout_thread.join()
            stderr_thread.join()

            # set dorne name in launch file
            setdronename(target,ws_abb)
        else:
            print(f"Target {target_ip} is Un Reachable")



def setdronename(target,ws_abb):

    # create local tmp folder
    create_tmp_directory()


    target_ip = target['ip']
    targetPass = target['password']
    target_username = target['username']
    localLaunchFileName = f"flight_controller.launch"
    localLaunchFileDir = f"tmp"
    remoteLaunchFileDir = f"~/HEAR_{ws_abb}/src/HEAR_{ws_abb}/Flight_controller/launch"
    localLaunchFilePath = f"{localLaunchFileDir}/{target_ip}_{localLaunchFileName}"
    drone_name = target['drone_name']


    # get launch file from remote target
    task = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} scp   {target_username}@{target_ip}:{remoteLaunchFileDir}/{localLaunchFileName} {localLaunchFilePath}"
        ], stdout=subprocess.PIPE
    )
    fileContents = open(localLaunchFilePath, "r").read()

    # find and erplace drone_name value
    matches = re.findall('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', fileContents)

    if len(matches) > 0:
        print(matches)
        rplce = re.sub('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', f'<arg name="DRONE_NAME" value="{drone_name}"', fileContents)

    else:
        print(matches)
        rplce = re.sub('<arg name="[DRONE_NAME\"]*"\s*', f'<arg name="DRONE_NAME" value="{drone_name}"', fileContents)

    # save replaced file locally
    with open(localLaunchFilePath, "w") as wfile:
        wfile.write(rplce)

    #tranfer local launch file to remote target
    taskMV = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} scp  {localLaunchFilePath} {target_username}@{target_ip}:{remoteLaunchFileDir}/{localLaunchFileName}"
        ], stdout=subprocess.PIPE
    )
# sed -i 's/arg name="DRONE_NAME"/arg name="DRONE_NAME"/g'  ~/HEAR_FC/src/HEAR_FC/Flight_controller/launch/flight_controller.launch

# ^\arg name="DRONE_NAME"\s*value="[^\"]*"
# <arg\s*+name="\".*\"\s*"
# ^\<arg name="[DRONE_NAME\"]*"\s*value="[^\"]*"
#         replaceDRONE_NAMECommand = f"if grep -q "['\<arg] name="[DRONE_NAME\"]*"\s*value="[^\"]*"" ~/HEAR_FC/src/HEAR_FC/Flight_controller/launch/flight_controller.launch; then sed -i 's/^\<arg name="['DRONE_NAME\"]*"\s*value="[^\"]*"/\ROS_MASTER_URI={target_ip}/' .bashrc && source ~/.bashrc; else echo 'ROS_MASTER_URI={target_ip}' >> ~/.bashrc && source ~/.bashrc ; fi\n".encode()

@app.callback(invoke_without_command=True)
def callback(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        fleet()


    # if ctx.invoked_subcommand == "fleet":
    #     fleet()
    # elif ctx.invoked_subcommand == "tmp":
    #     tmp()



if __name__ == "__main__":
    app()