import typer
from typing_extensions import Annotated
from PyInquirer import prompt, print_json, Separator
from enum import Enum
import json
import subprocess
from rich.prompt import Confirm
from rich.prompt import Prompt

import hear_cli.data as data
import hear_cli.utils as utils
import sys
app = typer.Typer(help="Build HEAR_FC or HEAR_MC for a choosen target",rich_markup_mode="rich",epilog="Made with :heart:  by [bold blue]Hashim[/bold blue]")



module_list_question = questions = [
    {
        "type": "list",
        "name": "target",
        "message": "Select your target: ",
        "choices": data.target_choices
    }
]
def validate_GITHUB_TOKEN(data):
    if data == "" :
        return False
    return True

@app.command("build")
def build():
    """
    [bold violet]Build HEAR_FC or HEAR_MC with a choosen target[/bold violet] :boom:  :boom: :sparkles:

    """
    target = ""

    # get and save target
    if utils.isTargetSeted(data.TargetConfigKeys.dev_target.name):
        target = utils.getTarget(data.TargetConfigKeys.dev_target.name)
        print(target)
    else:
        target = utils.chooseTarget()
        utils.saveTarget(target,data.TargetConfigKeys.dev_target.name)


    if target == data.Targets.ORIN.name:
        build_command = ''
        if utils.isDirExist('devel'):
            build_command = f'catkin_make -DCMAKE_BUILD_TYPE=Debug -DHEAR_TARGET={target}'
        else:
            build_command = f'catkin_make clean -DHEAR_TARGET={target} && catkin_make clean -DHEAR_TARGET={target} && catkin_make -DCMAKE_BUILD_TYPE=Debug -DHEAR_TARGET={target}'


        checkUploadConfirm = Confirm.ask(
            f":star2: Will  run: {build_command}  ? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        subprocess.run(
            [
                "bash",
                "-c",
                build_command
            ]
        )


    elif target == data.Targets.RPI.name:
        build_command = ''
        if utils.isDirExist('devel'):
            build_command = f'catkin_make -DCMAKE_BUILD_TYPE=Debug -DHEAR_TARGET={target}'
        else:
            build_command = f'catkin_make clean -DHEAR_TARGET={target} && catkin_make clean -DHEAR_TARGET={target} && catkin_make -DCMAKE_BUILD_TYPE=Debug -DHEAR_TARGET={target}'


        checkUploadConfirm = Confirm.ask(
            f":star2: Will  run: {build_command}  ? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        subprocess.run(
            [
                "bash",
                "-c",
                build_command
            ]
        )



    elif target == data.Targets.SITL.name:
        build_command = ''
        if utils.isDirExist('devel'):
            build_command = f'catkin_make -DCMAKE_BUILD_TYPE=Debug -DHEAR_TARGET={target}'
        else:
            build_command = f'catkin_make clean -DHEAR_TARGET={target} && catkin_make clean -DHEAR_TARGET={target} && catkin_make -DCMAKE_BUILD_TYPE=Debug -DHEAR_TARGET={target}'


        checkUploadConfirm = Confirm.ask(
            f":star2: Will  run: {build_command}  ? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        subprocess.run(
            [
                "bash",
                "-c",
                build_command
            ]
        )
    else:
        sys.exit("Error happened, please refer this to hashim")
    # subprocess.run(['bash', '-c','pushd src/targets/SITL_UBUNTU20;sudo ./full_system_installation.sh; popd'])



@app.command("configure")
def configure():
    """
    [bold violet]Update current command saved arguments that already been set[/bold violet] :boom:  :boom: :sparkles:

    """

    config_need = ""
    specific_config_need = ""
    config_need = utils.chooseConfigureCommand()

    if config_need == data.configure_choicesKeys['Set all configs'].name:
        set_dev_target(True)


        print(config_need)
    elif config_need == data.configure_choicesKeys['Set specific config'].name:
        print(config_need)
        specific_config_need = utils.chooseDevConfigureSpecificCommand()
        if specific_config_need == data.ConfigKeys.dev_target.name:
            set_dev_target(True)






def set_dev_target(mandatory=False):
    target=''
    # get and save dev_target
    if (mandatory is False) and utils.isTargetSeted(data.TargetConfigKeys.dev_target.name):
        target = utils.getTarget(data.TargetConfigKeys.dev_target.name)
        print(target)
    else:
        target = utils.chooseTarget()
        utils.saveTarget(target,data.TargetConfigKeys.dev_target.name)

    return target




def set_GITHUB_ID(mandatory=False):
    GITHUB_ID = ''
    # get and save GITHUB_ID
    if (mandatory is True) or utils.getValueByKey(data.ConfigKeys.GITHUB_ID.name) is None:
        GITHUB_ID = Prompt.ask("Enter your GITHUB_ID :sunglasses:")
        utils.saveValueByKey(GITHUB_ID,data.ConfigKeys.GITHUB_ID.name)
    else:
        GITHUB_ID = utils.getValueByKey(data.ConfigKeys.GITHUB_ID.name)

    return GITHUB_ID


def set_GITHUB_TOKEN(mandatory=False):
    # get and save GITHUB_TOKEN
    if (mandatory is True) or utils.getValueByKey(data.ConfigKeys.GITHUB_TOKEN.name) is None:
        # GITHUB_TOKEN = Prompt.ask("Enter your GITHUB_TOKEN :sunglasses:")
        # GITHUB_TOKEN = typer.prompt('Password', confirmation_prompt=True, hide_input=True)
        questions = [
            {
                'type': 'password',
                'name': 'GITHUB_TOKEN',
                'message': 'Enter your GITHUB_TOKEN',
            }
        ]

        answers = prompt(questions,validate=validate_GITHUB_TOKEN)
        GITHUB_TOKEN = answers["GITHUB_TOKEN"]

        utils.saveValueByKey(GITHUB_TOKEN,data.ConfigKeys.GITHUB_TOKEN.name)
    else:
        GITHUB_TOKEN = utils.getValueByKey(data.ConfigKeys.GITHUB_TOKEN.name)


    return GITHUB_TOKEN


def set_WS_NAME(mandatory=False):
    WS_NAME=''
    # get and save ws_name
    if (mandatory is True) or utils.getValueByKey(data.ConfigKeys.WS_NAME.name) is None:
        WS_NAME = utils.chooseDevWsName()
        utils.saveValueByKey(WS_NAME,data.ConfigKeys.WS_NAME.name)
    else:
        WS_NAME = utils.getValueByKey(data.ConfigKeys.WS_NAME.name)

    return WS_NAME








@app.callback()
def callback():
    pass



if __name__ == "__main__":
    app()