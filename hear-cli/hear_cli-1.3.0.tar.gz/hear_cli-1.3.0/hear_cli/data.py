from enum import Enum


class Targets(Enum):
    ORIN = 'ORIN'
    RPI = 'RPI'
    SITL = 'SITL'

class Workspaces(Enum):
    HEAR_FC = 'HEAR_FC'
    HEAR_MC = 'HEAR_MC'


class TargetConfigKeys(Enum):
    init_target = 'init_target'
    docker_target = 'docker_target'
    dev_target = 'dev_target'


class ConfigKeys(Enum):
    init_target = 'init_target'
    docker_target = 'docker_target'
    dev_target = 'dev_target'
    GITHUB_ID = 'GITHUB_ID'
    GITHUB_TOKEN = 'GITHUB_TOKEN'
    WS_NAME = 'WS_NAME'


# class configure_choicesKeys(Enum):
#     Set_all_configs = 'Set all configs'
#     Set_specific_config = 'Set specific config'


configure_choicesKeys = Enum('configure_choicesKeys', ['Set all configs', 'Set specific config'])






target_choices = [
    {
        "name": "ORIN",
        "value": "ORIN",
    },
    {
        "name": "RPI",
        "value": "RPI",
    },
    {
        "name": "SITL",
        "value": "SITL",
    }
]

ws_name_choices = [
    {
        "name": "HEAR_FC",
        "value": "HEAR_FC",

    },
    {
        "name": "HEAR_MC",
        "value": "HEAR_MC",

    }
]

configure_choices = [
    {
        "name": configure_choicesKeys['Set all configs'].name,
        "value": configure_choicesKeys['Set all configs'].name,
        
    },
    {
        "name": configure_choicesKeys['Set specific config'].name,
        "value": configure_choicesKeys['Set specific config'].name,
    }
]

target_configure_specific_choices = [
    {
        "name": ConfigKeys.init_target.name,
        "value": ConfigKeys.init_target.name,
    }

]

dev_configure_specific_choices = [
    {
        "name": ConfigKeys.dev_target.name,
        "value": ConfigKeys.dev_target.name,
    }

]



docker_configure_specific_choices = [
    {
        "name": ConfigKeys.docker_target.name,
        "value": ConfigKeys.docker_target.name,
    },
    {
        "name": ConfigKeys.GITHUB_ID.name,
        "value": ConfigKeys.GITHUB_ID.name,
    },
    {
        "name": ConfigKeys.GITHUB_TOKEN.name,
        "value": ConfigKeys.GITHUB_TOKEN.name,
    },
    {
        "name": ConfigKeys.WS_NAME.name,
        "value": ConfigKeys.WS_NAME.name,
    },


]

