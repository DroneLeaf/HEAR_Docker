import typer
from typing_extensions import Annotated
from InquirerPy import prompt
from enum import Enum
import json
import subprocess
from rich.prompt import Confirm

import json
import hear_cli.data as data
import sys
import getpass
import os
import socket
module_list_question = questions = [
    {
        "type": "list",
        "name": "target",
        "message": "Select your target: ",
        "choices": data.target_choices
    }
]

module_ws_name_question = questions = [
    {
        "type": "list",
        "name": "ws_name",
        "message": "Select your Dev Workspace: ",
        "choices": data.ws_name_choices
    }
]

module_target_ws_name_question = questions = [
    {
        "type": "list",
        "name": "ws_name",
        "message": "Select your Dev Workspace: ",
        "choices": data.ws_name_choices
    }
]




module_configure_question = questions = [
    {
        "type": "list",
        "name": "res",
        "message": "Pick up a choice: ",
        "choices": data.configure_choices
    }
]


module_docker_configure_specific_question = questions = [
    {
        "type": "list",
        "name": "res",
        "message": "Pick up a choice: ",
        "choices": data.docker_configure_specific_choices
    }
]




module_target_configure_specific_question = questions = [
    {
        "type": "list",
        "name": "res",
        "message": "Pick up a choice: ",
        "choices": data.target_configure_specific_choices
    }
]





module_dev_configure_specific_question = questions = [
    {
        "type": "list",
        "name": "res",
        "message": "Pick up a choice: ",
        "choices": data.dev_configure_specific_choices
    }
]






def isTargetSeted(target_key):
    configData = readFile("hear_cli_config.json")
    if type(configData) is str:
        configData = configData.replace("'", '"')
        configData = json.loads(configData)

    if (configData is not None) and target_key in configData:
        if configData[target_key] == data.Targets.ORIN.name or configData[target_key] == data.Targets.RPI.name or configData[target_key] == data.Targets.SITL.name:
            return True
        else:
            return False
    else:
        return False


def saveTarget(target_value,target_key):
    configData = readFile("hear_cli_config.json")
    if configData is None:
        configData = {}
    if type(configData) is str:
        configData = configData.replace("'", '"')
        configData = json.loads(configData)

    configData[target_key] = target_value
    writeFile("hear_cli_config.json", configData)
    print(readFile("hear_cli_config.json"))



def saveValueByKey(value,key):
    configData = readFile("hear_cli_config.json")
    if configData is None:
        configData = {}
    if type(configData) is str:
        configData = configData.replace("'", '"')
        configData = json.loads(configData)

    configData[key] = value
    writeFile("hear_cli_config.json", configData)
    print(readFile("hear_cli_config.json"))




def getTarget(target_key):
    configData = readFile("hear_cli_config.json")
    if type(configData) is str:
        configData = configData.replace("'", '"')
        configData = json.loads(configData)

    if target_key in configData:
        return configData[target_key]
    else:
        return None


def getValueByKey(key):
    configData = readFile("hear_cli_config.json")
    if type(configData) is str:
        configData = configData.replace("'", '"')
        configData = json.loads(configData)

    if key in configData:
        return configData[key]
    else:
        return None



def readFile(filepath):
    try:
        fp = open(filepath)
        return fp.read()
    except PermissionError:
        sys.exit("open config file PermissionError")
    except FileNotFoundError:
        return None
    else:
        with fp:
            return fp.read()


def writeFile(filepath, date):
    with open(filepath, "w", opener=None) as f:
        print(date, file=f)

def isDirExist(dir):
    if os.path.isdir(dir):
        return True
    else:
        return False

def chooseTarget():
    target = ""
    try:

        targetchoice = prompt(module_list_question)
        if type(targetchoice) is str:
            targetchoice = targetchoice.replace("'", '"')
            targetchoice = json.loads(targetchoice)
            target = targetchoice["target"]
        elif type(targetchoice) is tuple:
            target = targetchoice[0]["target"]

        elif type(targetchoice) is dict:
            target = targetchoice["target"]
        else:
            target = targetchoice["target"]
    except Exception as e:
        sys.exit(e)

    return target


def chooseDevWsName():
    target = ""
    try:
        targetchoice = prompt(module_ws_name_question)
        if type(targetchoice) is str:
            targetchoice = targetchoice.replace("'", '"')
            targetchoice = json.loads(targetchoice)
            target = targetchoice["ws_name"]
        elif type(targetchoice) is tuple:
            target = targetchoice[0]["ws_name"]

        elif type(targetchoice) is dict:
            target = targetchoice["ws_name"]
        else:
            target = targetchoice["ws_name"]

    except Exception as e:
        sys.exit(e)


    return target




def chooseConfigureCommand():
    target = ""
    try:
        targetchoice = prompt(module_configure_question)
        if type(targetchoice) is str:
            targetchoice = targetchoice.replace("'", '"')
            targetchoice = json.loads(targetchoice)
            target = targetchoice["res"]
        elif type(targetchoice) is tuple:
            target = targetchoice[0]["res"]

        elif type(targetchoice) is dict:
            target = targetchoice["res"]
        else:
            target = targetchoice["res"]

    except Exception as e:
        sys.exit(e)

    return target




def chooseDockerConfigureSpecificCommand():
    target = ""
    try:
        targetchoice = prompt(module_docker_configure_specific_question)
        if type(targetchoice) is str:
            targetchoice = targetchoice.replace("'", '"')
            targetchoice = json.loads(targetchoice)
            target = targetchoice["res"]
        elif type(targetchoice) is tuple:
            target = targetchoice[0]["res"]

        elif type(targetchoice) is dict:
            target = targetchoice["res"]
        else:
            target = targetchoice["res"]

    except Exception as e:
        sys.exit(e)


    return target

def chooseTargetConfigureSpecificCommand():
    target = ""
    try:
        targetchoice = prompt(module_target_configure_specific_question)
        if type(targetchoice) is str:
            targetchoice = targetchoice.replace("'", '"')
            targetchoice = json.loads(targetchoice)
            target = targetchoice["res"]
        elif type(targetchoice) is tuple:
            target = targetchoice[0]["res"]

        elif type(targetchoice) is dict:
            target = targetchoice["res"]
        else:
            target = targetchoice["res"]


    except Exception as e:
        sys.exit(e)

    return target


def chooseDevConfigureSpecificCommand():
    target = ""
    try:
        targetchoice = prompt(module_dev_configure_specific_question)
        if type(targetchoice) is str:
            targetchoice = targetchoice.replace("'", '"')
            targetchoice = json.loads(targetchoice)
            target = targetchoice["res"]
        elif type(targetchoice) is tuple:
            target = targetchoice[0]["res"]

        elif type(targetchoice) is dict:
            target = targetchoice["res"]
        else:
            target = targetchoice["res"]

    except Exception as e:
        sys.exit(e)

    return target




def getSystemUserName():
    return getpass.getuser()

def get_hostname():
    return socket.gethostname()


def get_local_ip():
    try:
        # Create a socket object
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Connect to some external server, doesn't really matter which one
        s.connect(('8.8.8.8', 80))

        # Get the local IP address
        local_ip = s.getsockname()[0]

        # Close the socket
        s.close()

        return local_ip
    except Exception as e:
        # print("Error:", e)
        return None