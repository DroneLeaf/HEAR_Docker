import typer
from typing_extensions import Annotated
# from InquirerPy import prompt
from enum import Enum
import json
import subprocess
from subprocess import Popen, PIPE
from rich import print as rprint

from rich.prompt import Confirm
from rich.prompt import Prompt
import os

import hear_cli.data as data
import hear_cli.utils as utils
import time
import logging
import threading
import re
import socket
import sys
import asyncio
import time
import threading
import multiprocessing
from joblib import Parallel, delayed
from multiprocessing import Pool
import time
import math

import math
from timebudget import timebudget
from multiprocessing import Pool
import socket

import re, sys

app = typer.Typer(help="[bold violet]update compiled files, update ROS_MASTER_URI, and drone_name launch arg  [/bold violet] [bold green]on all hear_configurtions drones [/bold green] :boom:  :boom: :sparkles:",rich_markup_mode="rich",epilog="Made with :heart:  by [bold blue]Hashim[/bold blue] [bold green]@ DroneLeaf[/bold green]")

targetsData = []
uav_instance_json_data_stringified = {}
operator_instance_json_data_stringified = ''


def isTargetReachable(ip):
    ClientSocket = socket.socket()
    ClientSocket.settimeout(5)
    try:
        ClientSocket.connect((ip, 22))
        ClientSocket.close()
        return True

        # port = 22
    except socket.error:
        ClientSocket.close()
        return False


# @app.command("cloneConfigurations")
def cloneConfigurations():
    # create local tmp folder
    create_tmp_directory()

    # clone HEAR_Configurations
    if os.path.isdir("tmp/HEAR_Configurations"):
        tmp = subprocess.run(
            [
                "bash",
                "-c",
                "cd tmp/HEAR_Configurations && git pull"
            ], stdout=subprocess.PIPE
        )

    else:
        tmp = subprocess.run(
            [
                "bash",
                "-c",
                "git clone -b devel https://github.com/HazemElrefaei/HEAR_Configurations.git tmp/HEAR_Configurations "
            ], stdout=subprocess.PIPE
        )

def aggrgateTargetsData(ROS_MASTER_URI="",operator_name=""):
    # aggregate targets data

    UAV_instances = []
    global operator_instance_json_data_stringified

    try:
        Fleets = os.listdir("tmp/HEAR_Configurations/Missions/Fleets")
    except Exception as e:
        rprint("[yellow]please execute this command manualy:[/yellow] [red bold] git clone -b devel https://github.com/HazemElrefaei/HEAR_Configurations.git tmp/HEAR_Configurations[/red bold]")

        sys.exit(e)


    for fleet in Fleets:
        if os.path.isdir(f'tmp/HEAR_Configurations/Missions/Fleets/{fleet}'):
            instanceGeneral = utils.readFile(f'tmp/HEAR_Configurations/Missions/Fleets/{fleet}/general.json')
            instanceGeneralJson = json.loads(instanceGeneral)
            UAV_instances_key = instanceGeneralJson['UAV_instances']
            UAV_instances.extend(UAV_instances_key)

    print("Fleets >> ",UAV_instances)
    # print("UAV_instancesss")

    ## get operator data
    # operator_name = "ahmed_hshim"
    if os.path.isdir(f'tmp/HEAR_Configurations/Missions/Operators/{operator_name}'):
            operatorGeneral = utils.readFile(f'tmp/HEAR_Configurations/Missions/Operators/{operator_name}/general.json')
            # operatorGeneralJson = json.loads(operatorGeneral)
            operator_instance_json_data_stringified = operatorGeneral



    # try:
    #     UAV_instances = os.listdir("tmp/HEAR_Configurations/UAV_instances")
    # except Exception as e:
    #     rprint("[yellow]please execute this command manualy:[/yellow] [red bold] git clone -b devel https://github.com/HazemElrefaei/HEAR_Configurations.git tmp/HEAR_Configurations[/red bold]")
    #
    #     sys.exit(e)



    
    try:
        # print(UAV_instances)
        for instance in UAV_instances:
            # print(instance)

            if os.path.isdir(f'tmp/HEAR_Configurations/UAV_instances/{instance}'):
                instanceGeneral = utils.readFile(f'tmp/HEAR_Configurations/UAV_instances/{instance}/general.json')
                instanceGeneralJson = json.loads(instanceGeneral)
                ip = instanceGeneralJson['ip']
                # uav_instance_json_data_stringified[ip] = instanceGeneral
                uav_type = instanceGeneralJson['uav_type']
                typeGeneral =  utils.readFile(f'tmp/HEAR_Configurations/UAV_types/{uav_type}/general.json')
                typeGeneralJson = json.loads(typeGeneral)
                targetName = typeGeneralJson['running_target']
                # print(ip)
                # print(targetName)
                if ip != '0.0.0.0':
                    targetObj={"ip":ip,"username":"pi","password":"raspberry","ROS_MASTER_URI":ROS_MASTER_URI,"drone_name":instance,"HEAR_FC":True,"HEAR_MC":True}
    
                    if targetName == "RPI_UBUNTU20":
                        targetObj["username"]= "pi"
                        targetObj["password"]= "raspberry"
    
                    elif targetName == "ORIN_UBUNTU20":
                        targetObj["username"]= "orin"
                        targetObj["password"]= "orin"
    
                    targetsData.append(targetObj)
    except Exception as e:
        sys.exit(e) 

    

    
    
    # print(targetsData)
def create_tmp_directory():
    if os.path.isdir("tmp") is False:

        tmp = subprocess.run(
            [
                "bash",
                "-c",
                "mkdir tmp "
            ], stdout=subprocess.PIPE
        )

def process_item(item):
    # Your processing logic here
    # asyncio.sleep(1)  # Simulate some asynchronous processing
    print(f"started at {time.strftime('%X')}")

    print(f"Processing item: {item}")
    print(f"finished at {time.strftime('%X')}")


# @app.command("test")
def test():
    try:
        items = [1, 2, 3, 4, 5]

        # Create a list of asyncio tasks
        tasks = [process_item(item) for item in items]
        asyncio.gather(*tasks)
    except Exception as e :
        print()

def targetsLoopInParallel(target,ws_abb):
    target_ip = target['ip']
    ROS_MASTER_URI = target['ROS_MASTER_URI']
    targetPass = target['password']
    target_username = target['username']
    localLaunchFileName = f"flight_controller.launch"
    localLaunchFileDir = f"tmp"
    remoteLaunchFileDir = f"~/HEAR_{ws_abb}/src/HEAR_{ws_abb}/Flight_controller/launch"
    scriptsDir = "dev"
    scriptsRemoteLaunchFileDir = f"~/{scriptsDir}"
    localLaunchFilePath = f"{localLaunchFileDir}/{target_ip}_{localLaunchFileName}"
    drone_name = target['drone_name']
    print(f"{target_ip} started at {time.strftime('%X')}")
    # replaceCommand = f"if grep -q ROS_MASTER_URI .bashrc; then sed -i 's/^\(export\s*ROS_MASTER_URI\s*=\s*\).*$/\export ROS_MASTER_URI={ROS_MASTER_URI}/' .bashrc && source ~/.bashrc; else echo 'ROS_MASTER_URI={ROS_MASTER_URI}' >> ~/.bashrc && source ~/.bashrc ; fi\n".encode()


    

    drone_name_changerFileName = f"ros_master_uri_changer.sh"
    drone_name_changerFilePath = get_file_path_in_same_directory("src/scripts/"+drone_name_changerFileName)
    drone_name_changerFileNameRemotaPath = f"{scriptsRemoteLaunchFileDir}/{drone_name_changerFileName}"

    taskMV1 = subprocess.run(
        [
            "bash",
            "-c",
            f"sudo chmod +x {drone_name_changerFileName}"
        ], stdout=subprocess.PIPE
    )

    

    mkdir = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} ssh {target_username}@{target_ip} 'echo '{targetPass}' | sudo -S echo 'start sudo' | mkdir {scriptsRemoteLaunchFileDir}'"
        ], stdout=subprocess.PIPE
    )

    taskMV = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} scp  {drone_name_changerFilePath} {target_username}@{target_ip}:{drone_name_changerFileNameRemotaPath}"
        ], stdout=subprocess.PIPE
    )

    

    

    
    print(f"sshpass -p {targetPass} {target_username}@{target_ip} 'mkdir {scriptsRemoteLaunchFileDir}'")

    


    if isTargetReachable(target_ip):

        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        # p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)


        def read_stdout():
            for line in iter(p.stdout.readline, ''):
                print(line, end='')


        def read_stderr():
            for line in iter(p.stderr.readline, ''):
                print(line, end='')



        con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

        p.stdin.write(con1)
        p.stdin.flush()



        ## all commands
        sudo_init = f"echo '{targetPass}' | sudo -S echo 'start sudo' \n".encode()
        # mkDevFolder = f"mkdir  {scriptsRemoteLaunchFileDir}\n".encode()
        chmodFile = f" sudo chmod +x {drone_name_changerFileNameRemotaPath} \n".encode()
        changer_file_run = f" {drone_name_changerFileNameRemotaPath} {ROS_MASTER_URI} \n".encode()
        removeFile = f" rm {drone_name_changerFileNameRemotaPath} \n".encode()
        # replaceCommand = f"if grep -q ROS_MASTER_URI .bashrc; then sed -i 's/^\(export\s*ROS_MASTER_URI\s*=\s*\).*$/\export ROS_MASTER_URI={currentTargetHosdasdsadstName}/' .bashrc && source ~/.bashrc; else echo 'export ROS_MASTER_URI={currentTargetHosdasdsadstName}' >> ~/.bashrc && source ~/.bashrc ; fi\n".encode()
        packagesInstall = f'echo {targetPass} | sudo -S apt install unzip wget -y\n'.encode()
        compiledZippedDownload = f'wget https://hear-bucket.s3.me-south-1.amazonaws.com/hear_arch/hear_{ws_abb.lower()}_devel.zip -O hear_fc_devel_compiled.zip \n'.encode()
        unzipFile = f'unzip -o hear_{ws_abb.lower()}_devel_compiled.zip -d hear_{ws_abb.lower()}_devel_compiled\n'.encode()

        cpFolder = f'cp -rf  hear_{ws_abb.lower()}_devel_compiled/compiled_files ~/HEAR_{ws_abb}\n'.encode()
        exit = b'exit\n'
        cpFolder = f'cp -rf  hear_{ws_abb.lower()}_devel_compiled/compiled_files ~/HEAR_{ws_abb}\n'.encode()
        exit = b'exit\n'

        print(sudo_init)
        commands = [sudo_init,chmodFile,changer_file_run,packagesInstall,compiledZippedDownload,unzipFile,cpFolder,exit]
        # commands = [exit]

        # Execute each command and print the output in real-time
        # Start threads to continuously read from stdout and stderr
        stdout_thread = threading.Thread(target=read_stdout)
        stderr_thread = threading.Thread(target=read_stderr)
        stdout_thread.start()
        stderr_thread.start()


        # Execute each command and write to stdin
        for command in commands:
            p.stdin.write(command.decode() + "\n")
            p.stdin.flush()


        # Close stdin to signal the end of input
        p.stdin.close()

        # Wait for the subprocess to finish
        p.wait()


        # Join the threads to wait for them to complete
        stdout_thread.join()
        stderr_thread.join()


        # set dorne name in launch file
        setdronename(target,ws_abb)
    else:
        print(f"Target {target_ip} is Un Reachable")
        # set dorne name in launch file
        # setdronename(target,ws_abb)

    # print(f"{target_ip} end at {time.strftime('%X')}")

    # print(f"{target_ip} end at {time.strftime('%X')}")

def changeLoaclServerUri(target,ws_abb):
    target_ip = target['ip']
    ROS_MASTER_URI = target['ROS_MASTER_URI']
    targetPass = target['password']
    target_username = target['username']
    localLaunchFileName = f"flight_controller.launch"
    localLaunchFileDir = f"tmp"
    remoteLaunchFileDir = f"~/HEAR_{ws_abb}/src/HEAR_{ws_abb}/Flight_controller/launch"
    scriptsDir = "dev"
    scriptsRemoteLaunchFileDir = f"~/{scriptsDir}"
    localLaunchFilePath = f"{localLaunchFileDir}/{target_ip}_{localLaunchFileName}"
    drone_name = target['drone_name']
    print(f"{target_ip} started at {time.strftime('%X')}")
    # replaceCommand = f"if grep -q ROS_MASTER_URI .bashrc; then sed -i 's/^\(export\s*ROS_MASTER_URI\s*=\s*\).*$/\export ROS_MASTER_URI={ROS_MASTER_URI}/' .bashrc && source ~/.bashrc; else echo 'ROS_MASTER_URI={ROS_MASTER_URI}' >> ~/.bashrc && source ~/.bashrc ; fi\n".encode()


    

    drone_name_changerFileName = f"local_server_uri_changer.sh"
    drone_name_changerFilePath = get_file_path_in_same_directory("src/scripts/"+drone_name_changerFileName)
    drone_name_changerFileNameRemotaPath = f"{scriptsRemoteLaunchFileDir}/{drone_name_changerFileName}"

    taskMV1 = subprocess.run(
        [
            "bash",
            "-c",
            f"sudo chmod +x {drone_name_changerFileName}"
        ], stdout=subprocess.PIPE
    )

    

    mkdir = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} ssh {target_username}@{target_ip} 'echo '{targetPass}' | sudo -S echo 'start sudo' | mkdir {scriptsRemoteLaunchFileDir}'"
        ], stdout=subprocess.PIPE
    )

    taskMV = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} scp  {drone_name_changerFilePath} {target_username}@{target_ip}:{drone_name_changerFileNameRemotaPath}"
        ], stdout=subprocess.PIPE
    )

    

    

    
    print(f"sshpass -p {targetPass} {target_username}@{target_ip} 'mkdir {scriptsRemoteLaunchFileDir}'")

    


    if isTargetReachable(target_ip):

        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        # p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)


        def read_stdout():
            for line in iter(p.stdout.readline, ''):
                print(line, end='')


        def read_stderr():
            for line in iter(p.stderr.readline, ''):
                print(line, end='')



        con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

        p.stdin.write(con1)
        p.stdin.flush()



        ## all commands
        sudo_init = f"echo '{targetPass}' | sudo -S echo 'start sudo' \n".encode()
        # mkDevFolder = f"mkdir  {scriptsRemoteLaunchFileDir}\n".encode()
        chmodFile = f" sudo chmod +x {drone_name_changerFileNameRemotaPath} \n".encode()
        changer_file_run = f" {drone_name_changerFileNameRemotaPath} {ROS_MASTER_URI} \n".encode()
        removeFile = f" rm {drone_name_changerFileNameRemotaPath} \n".encode()
        
        exit = b'exit\n'


        print(sudo_init)
        commands = [sudo_init,chmodFile,changer_file_run,exit]
        # commands = [exit]

        # Execute each command and print the output in real-time
        # Start threads to continuously read from stdout and stderr
        stdout_thread = threading.Thread(target=read_stdout)
        stderr_thread = threading.Thread(target=read_stderr)
        stdout_thread.start()
        stderr_thread.start()


        # Execute each command and write to stdin
        for command in commands:
            p.stdin.write(command.decode() + "\n")
            p.stdin.flush()


        # Close stdin to signal the end of input
        p.stdin.close()

        # Wait for the subprocess to finish
        p.wait()


        # Join the threads to wait for them to complete
        stdout_thread.join()
        stderr_thread.join()


        # set dorne name in launch file
    else:
        print(f"Target {target_ip} is Un Reachable")
        # set dorne name in launch file
        # setdronename(target,ws_abb)

    # print(f"{target_ip} end at {time.strftime('%X')}")

    # print(f"{target_ip} end at {time.strftime('%X')}")



def get_file_path_in_same_directory(file_name):
   script_dir = os.path.dirname(os.path.abspath(__file__))
   file_path = os.path.join(script_dir, file_name)

   return file_path

def setdronename(target,ws_abb):

    # create local tmp folder
    create_tmp_directory()


    target_ip = target['ip']
    targetPass = target['password']
    target_username = target['username']
    remoteLaunchFileDir = f"~/HEAR_{ws_abb}/src/HEAR_{ws_abb}/Flight_controller/launch"

    localLaunchFileName = f"flight_controller.launch"
    localLaunchFileDir = f"tmp"
    localLaunchFilePath = f"{localLaunchFileDir}/{target_ip}_{localLaunchFileName}"
    drone_name_changerFileName = "drone_name_changer.py"
    drone_name_changerfile_path = get_file_path_in_same_directory("src/scripts/"+drone_name_changerFileName)
    drone_name_changerFileNameRemotaPath = f"{remoteLaunchFileDir}/{drone_name_changerFileName}"
    drone_name = target['drone_name']

    taskMV = subprocess.run(
        [
            "bash",
            "-c",
            f"sshpass -p {targetPass} scp  {drone_name_changerfile_path} {target_username}@{target_ip}:{drone_name_changerFileNameRemotaPath}"
        ], stdout=subprocess.PIPE
    )


    if isTargetReachable(target_ip):

        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

        def read_stdout():
            for line in iter(p.stdout.readline, ''):
                print(line, end='')

        def read_stderr():
            for line in iter(p.stderr.readline, ''):
                print(line, end='')



        con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

        p.stdin.write(con1)
        p.stdin.flush()


        ## all commands
        sudo_init = f"echo '{targetPass}' | sudo -S echo 'start sudo' \n".encode()
        python3_install = f"sudo apt update && sudo apt install python3 && sudo apt install python3-pip \n".encode()
        changer_file_run = f"python3 {drone_name_changerFileNameRemotaPath} {drone_name} {ws_abb} \n".encode()
        removeFile = f" rm {drone_name_changerFileNameRemotaPath} \n".encode()

        exit = b'exit\n'


        commands = [sudo_init,python3_install,changer_file_run,removeFile,exit]

        # Execute each command and print the output in real-time
        # Start threads to continuously read from stdout and stderr
        stdout_thread = threading.Thread(target=read_stdout)
        stderr_thread = threading.Thread(target=read_stderr)
        stdout_thread.start()
        stderr_thread.start()

        # Execute each command and write to stdin
        for command in commands:
            p.stdin.write(command.decode() + "\n")
            p.stdin.flush()

        # Close stdin to signal the end of input
        p.stdin.close()

        # Wait for the subprocess to finish
        p.wait()

        # Join the threads to wait for them to complete
        stdout_thread.join()
        stderr_thread.join()


    else:
        print(f"Target {target_ip} is Un Reachable")





    # # get launch file from remote target
    # task = subprocess.run(
    #     [
    #         "bash",
    #         "-c",
    #         f"sshpass -p {targetPass} scp   {target_username}@{target_ip}:{remoteLaunchFileDir}/{localLaunchFileName} {localLaunchFilePath}"
    #     ], stdout=subprocess.PIPE
    # )
    # fileContents = open(localLaunchFilePath, "r").read()
    #
    # # find and erplace drone_name value
    # matches = re.findall('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', fileContents)
    #
    # if len(matches) > 0:
    #     print(matches)
    #     rplce = re.sub('<arg name="[DRONE_NAME\"]*"\s*value="[\w\d\"]*', f'<arg name="DRONE_NAME" value="{drone_name}"', fileContents)
    #
    # else:
    #     print(matches)
    #     rplce = re.sub('<arg name="[DRONE_NAME\"]*"\s*', f'<arg name="DRONE_NAME" value="{drone_name}"', fileContents)
    #
    # # save replaced file locally
    # with open(localLaunchFilePath, "w") as wfile:
    #     wfile.write(rplce)
    #
    # #tranfer local launch file to remote target
    # taskMV = subprocess.run(
    #     [
    #         "bash",
    #         "-c",
    #         f"sshpass -p {targetPass} scp  {localLaunchFilePath} {target_username}@{target_ip}:{remoteLaunchFileDir}/{localLaunchFileName}"
    #     ], stdout=subprocess.PIPE
    # )


def changeTargetsHostname(target):

    target_ip = target['ip']
    targetPass = target['password']
    target_username = target['username']

    instanceName = target['drone_name']
    currentTargetHostName = ""
    if isTargetReachable(target_ip):

        task = subprocess.run(
            [
                "bash",
                "-c",
                f"sshpass -p {targetPass} ssh {target_username}@{target_ip} hostname"
            ], stdout=subprocess.PIPE
        )
        # task.stdout.read
        currentTargetHostName = task.stdout.decode()
        print(currentTargetHostName)



        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

        def read_stdout():
            for line in iter(p.stdout.readline, ''):
                print(line, end='')

        def read_stderr():
            for line in iter(p.stderr.readline, ''):
                print(line, end='')



        con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

        p.stdin.write(con1)
        p.stdin.flush()


        ## all commands
        sudo_init = f"echo {targetPass} | sudo -S echo 'start sudo'\n".encode()
        whoami = f"sudo  -u root whoami \n".encode()
        cloud_init = f"sudo -u root sed -i 's/^\preserve_hostname:\s*\w*/\preserve_hostname: true/' /etc/cloud/cloud.cfg\n".encode()
        set_hostname = f"sudo hostnamectl set-hostname {instanceName}\n".encode()
        change_hostname = f"sudo -u root sed -i 's/[1][2][7][.][0][.][1][.][1]\s*{currentTargetHostName}/127.0.1.1 {instanceName}/' /etc/hosts \n".encode()
        reboot = b'sudo reboot now\n'
        exit = b'exit\n'


        commands = [sudo_init,whoami,cloud_init,set_hostname,change_hostname,reboot,exit]

        # Execute each command and print the output in real-time
        # Start threads to continuously read from stdout and stderr
        stdout_thread = threading.Thread(target=read_stdout)
        stderr_thread = threading.Thread(target=read_stderr)
        stdout_thread.start()
        stderr_thread.start()

        # Execute each command and write to stdin
        for command in commands:
            p.stdin.write(command.decode() + "\n")
            p.stdin.flush()

        # Close stdin to signal the end of input
        p.stdin.close()

        # Wait for the subprocess to finish
        p.wait()

        # Join the threads to wait for them to complete
        stdout_thread.join()
        stderr_thread.join()


    else:
        print(f"Target {target_ip} is Un Reachable")

    # print(f"{target_ip} end at {time.strftime('%X')}")


def addTargetsToHostsFile(target,hosts):



    target_ip = target['ip']
    targetPass = target['password']
    target_username = target['username']

    instanceName = target['drone_name']
    currentTargetHostName = ""
    if isTargetReachable(target_ip):

        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

        def read_stdout():
            for line in iter(p.stdout.readline, ''):
                print(line, end='')

        def read_stderr():
            for line in iter(p.stderr.readline, ''):
                print(line, end='')



        con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

        p.stdin.write(con1)
        p.stdin.flush()


        ## all commands
        sudo_init = f"echo {targetPass} | sudo -S echo 'start sudo'\n".encode()
        su = f"sudo su - \n".encode()
        whoami = f"whoami \n".encode()
        replaceCommand = f"if grep -q 'Added by hear-cli' /etc/hosts; then perl -i~ -0777 -pe 's/# Added by hear-.* do not edit\s*\w*((.|\n)*)# end hear-.* hosts/\\{hosts}/' /etc/hosts ; else echo '{hosts}' >> /etc/hosts ; fi\n".encode()
        update_etc_hosts = f"sudo -u root sed -i 's/- update_etc_hosts/\# - update_etc_hosts/' /etc/cloud/cloud.cfg\n".encode()

        # addHosts = f"echo '{hosts}' >> /etc/hosts \n".encode()
        # print(f"echo '{hosts}' >> /etc/hosts \n")

        exit = b'exit\n'


        commands = [sudo_init,su,whoami,replaceCommand,update_etc_hosts,exit]

        # Execute each command and print the output in real-time
        # Start threads to continuously read from stdout and stderr
        stdout_thread = threading.Thread(target=read_stdout)
        stderr_thread = threading.Thread(target=read_stderr)
        stdout_thread.start()
        stderr_thread.start()

        # Execute each command and write to stdin
        for command in commands:
            p.stdin.write(command.decode() + "\n")
            p.stdin.flush()

        # Close stdin to signal the end of input
        p.stdin.close()

        # Wait for the subprocess to finish
        p.wait()

        # Join the threads to wait for them to complete
        stdout_thread.join()
        stderr_thread.join()


    else:
        print(f"Target {target_ip} is Un Reachable")




def runTargets(target,fileName,uav_instance_json_data_stringified,operator_instance_json_data_stringified):


    target_ip = target['ip']
    targetPass = target['password']
    target_username = target['username']

    instanceName = target['drone_name']
    currentTargetHostName = ""
    if isTargetReachable(target_ip):

        # p = subprocess.Popen(["bash"], stdin=subprocess.PIPE, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
        p = subprocess.Popen(['bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

        def read_stdout():
            for line in iter(p.stdout.readline, ''):
                print(line, end='')

        def read_stderr():
            for line in iter(p.stderr.readline, ''):
                print(line, end='')



        con1 = f"sshpass -p {targetPass} ssh {target_username}@{target_ip}\n"

        p.stdin.write(con1)
        p.stdin.flush()

        scriptsDir = "hear_cli_deploy"
        dirPath = f"/home/{target_username}/{scriptsDir}"

        drone_name_changerFileName = os.path.basename(fileName)
        drone_name_changerFilePath = fileName
        drone_name_changerFileNameRemotaPath = f"{dirPath}/{drone_name_changerFileName}"
    
        # taskMV1 = subprocess.run(
        #     [
        #         "bash",
        #         "-c",
        #         f"sudo chmod +x {drone_name_changerFileName}"
        #     ], stdout=subprocess.PIPE
        # )
    
        
    
        mkdir = subprocess.run(
            [
                "bash",
                "-c",
                f"sshpass -p {targetPass} ssh {target_username}@{target_ip} 'echo '{targetPass}' | sudo -S echo 'start sudo' | mkdir {dirPath}'"
            ], stdout=subprocess.PIPE
        )
        taskMV = subprocess.run(
            [
                "bash",
                "-c",
                f"sshpass -p {targetPass} scp  {drone_name_changerFilePath} {target_username}@{target_ip}:{drone_name_changerFileNameRemotaPath}"
            ], stdout=subprocess.PIPE
        )

        # dirPath = f"/home/{target_username}/HEAR_FC/src/HEAR_FC/Flight_controller/HEAR_executables/HEAR_CLI"


        ## all commands
        sudo_init = f"echo '{targetPass}' | sudo -S echo 'start sudo' \n".encode()
        packagesInstall = f'echo {targetPass} | sudo -S apt install jq -y\n'.encode()

        # su = f"sudo su - \n".encode()
        # suders_add_user_file = f"sudo echo '{target_username}  ALL=(ALL) NOPASSWD:{filePath}' >> /etc/sudoers \n".encode()

        cd_hear_fc = f"cd {dirPath} \n".encode()
        # chmod = f"echo '{targetPass}' | sudo -S  chmod +x {drone_name_changerFileNameRemotaPath} \n".encode()
        chmodFile = f" echo '{targetPass}' | sudo chmod +x {drone_name_changerFileNameRemotaPath} \n".encode()
        
        # run_shFile = f" ls && nohup  {dirPath}/{fileName}  </dev/null > test.log 2>&1 & \n".encode()
        run_shFile = f" ./{drone_name_changerFileName} '{uav_instance_json_data_stringified[target_ip]}'  '{operator_instance_json_data_stringified}'  </dev/null > {drone_name_changerFileNameRemotaPath}.log 2>&1 & \n".encode()

        # test_deploy.sh
        


        exit = b'exit\n'


        commands = [sudo_init,packagesInstall,cd_hear_fc,chmodFile,run_shFile,exit]

        # Execute each command and print the output in real-time
        # Start threads to continuously read from stdout and stderr
        stdout_thread = threading.Thread(target=read_stdout)
        stderr_thread = threading.Thread(target=read_stderr)
        stdout_thread.start()
        stderr_thread.start()

        # Execute each command and write to stdin
        for command in commands:
            p.stdin.write(command.decode() + "\n")
            p.stdin.flush()

        # Close stdin to signal the end of input
        p.stdin.close()

        # Wait for the subprocess to finish
        p.wait()

        # Join the threads to wait for them to complete
        stdout_thread.join()
        stderr_thread.join()


    else:
        print(f"Target {target_ip} is Un Reachable")




@app.command("fleet")
def fleet():
    """
    [bold violet]update compiled files, update ROS_MASTER_URI, and drone_name launch arg  [/bold violet] [bold green]on all hear_configurtions drones [/bold green] :boom:  :boom: :sparkles:

    """
    ws_name = utils.chooseDevWsName()
    ws_abb = ''
    if ws_name == data.Workspaces.HEAR_FC.name:
        ws_abb = "FC"
    else:
        ws_abb = "MC"

    default_ros_master_uri = "http://"+utils.get_local_ip()+":11311/"

    ros_master_uri = Prompt.ask("Enter ROS_MASTER_URI :sunglasses:",default=default_ros_master_uri)
    print(ros_master_uri)



    cloneConfigurations()
    aggrgateTargetsData(ros_master_uri)

    subprocess.run(
        [
            "bash",
            "-c",
            'sudo apt install sshpass -y'
        ]
    )

    # targets=[{"ip":"192.168.1.21","username":"pi","password":"raspberry","ROS_MASTER_URI":"192.168.1.21","drone_name":"UAV_1","HEAR_FC":True,"HEAR_MC":True}]
    targets=[{"ip":"10.0.0.55","username":"droneleaf","password":"droneleaf","ROS_MASTER_URI":ros_master_uri,"drone_name":"UAV_1","HEAR_FC":True,"HEAR_MC":True}]





    try:
        # Create a list of asyncio tasks
        tasks = [targetsLoopInParallel(target,ws_abb) for target in targetsData]
        asyncio.gather(*tasks)
    except Exception as e :
        print()


@app.command("set-local-server-uri")
def local_server_uri():
    """
    [bold violet]update compiled files, update ROS_MASTER_URI, and drone_name launch arg  [/bold violet] [bold green]on all hear_configurtions drones [/bold green] :boom:  :boom: :sparkles:

    """
    ws_name = utils.chooseDevWsName()
    ws_abb = ''
    if ws_name == data.Workspaces.HEAR_FC.name:
        ws_abb = "FC"
    else:
        ws_abb = "MC"

    default_ros_master_uri = "http://"+utils.get_local_ip()+":3000/"

    ros_master_uri = Prompt.ask("Enter LOCAL_SERVER_API_URI :sunglasses:",default=default_ros_master_uri)
    print(ros_master_uri)



    cloneConfigurations()
    aggrgateTargetsData(ros_master_uri)

    subprocess.run(
        [
            "bash",
            "-c",
            'sudo apt install sshpass -y'
        ]
    )

    # targets=[{"ip":"192.168.1.21","username":"pi","password":"raspberry","ROS_MASTER_URI":"192.168.1.21","drone_name":"UAV_1","HEAR_FC":True,"HEAR_MC":True}]
    targets=[{"ip":"10.0.0.55","username":"droneleaf","password":"droneleaf","ROS_MASTER_URI":ros_master_uri,"drone_name":"UAV_1","HEAR_FC":True,"HEAR_MC":True}]





    try:
        # Create a list of asyncio tasks
        tasks = [changeLoaclServerUri(target,ws_abb) for target in targetsData]
        asyncio.gather(*tasks)
    except Exception as e :
        print()




@app.command("update-hostnames")
def changehosts():
    """
    [bold violet]Change hostname in targets to be the instance name  [/bold violet] [bold green]on all HEAR_Configurations drones [/bold green] :boom:  :boom: :sparkles:

    """


    checkUploadConfirm = Confirm.ask(
        ":star2: Targets will be reboot after change hostname, Are you sure? :sunglasses:",
        default=True,
    )
    if not checkUploadConfirm:
        raise typer.Abort()

    cloneConfigurations()
    aggrgateTargetsData()

    targets=[{"ip":"192.168.1.21","username":"pi","password":"raspberry","ROS_MASTER_URI":"192.168.1.21","drone_name":"hashimrpi2","HEAR_FC":True,"HEAR_MC":True}]




    try:
        # Create a list of asyncio tasks
        tasks = [changeTargetsHostname(target) for target in targetsData]
        asyncio.gather(*tasks)
    except Exception as e :
        print(e)



@app.command("add-hostnames")
def changehosts():
    """
    [bold violet]Add all targets hostnames to /etc/hosts [/bold violet] [bold green]on all HEAR_Configurations drones [/bold green] :boom:  :boom: :sparkles:

    """

    hosts = "# Added by hear-cli :: :: :: do not edit\n"
    host_name = socket.gethostname()
    host_ip = socket.gethostbyname(host_name)

    ros_master_uri = Prompt.ask("Enter ROS_MASTER_URI IP :sunglasses:",default=utils.get_local_ip())
    print(ros_master_uri)

    ros_master_hostname = Prompt.ask("Enter ROS_MASTER_URI HOSTNAME :sunglasses:",default=utils.get_hostname())
    print(ros_master_hostname)

    hosts = hosts+ f"{ros_master_uri} {ros_master_hostname}\n"


    checkUploadConfirm = Confirm.ask(
        ":star2: All Drones IPs and Hostnames will be added to all targets in /etc/hosts, Are you sure? :sunglasses:",
        default=True,
    )
    if not checkUploadConfirm:
        raise typer.Abort()


    cloneConfigurations()
    aggrgateTargetsData()


    targets=[{"ip":"192.168.1.21","username":"pi","password":"raspberry","ROS_MASTER_URI":"192.168.1.21","drone_name":"hashimrpi","HEAR_FC":True,"HEAR_MC":True}]

    # aggregate hosts
    for target in targetsData:
        target_ip = target['ip']
        instanceName = target['drone_name']
        hosts = hosts+ f"{target_ip} {instanceName}\n"
    hosts = hosts+ f"# end hear-cli hosts\n"



    try:
        # Create a list of asyncio tasks
        tasks = [addTargetsToHostsFile(target,hosts) for target in targetsData]
        asyncio.gather(*tasks)
    except Exception as e :
        print(e)

def valid_path(path):
	# validate file path
     if not os.path.exists(path):
        raise typer.BadParameter("please enter a valid file path")
     
     return path
@app.command("deploy")
def run(filename: Annotated[str, typer.Option(help="edge deployment sh filename",metavar="edge_deploy.sh",prompt="Enter deployment filename",callback=valid_path)],
           operatorName: Annotated[str, typer.Option(help="Operator Name",metavar="Ahmed_Hashim",prompt="Enter Operator's Name")]):
    """
    [bold violet]Deploy Run sh file inside All fleet Edges . :sparkles:

    """

    checkUploadConfirm = Confirm.ask(
        ":star2: run file will be executed in all targets, Are you sure? :sunglasses:",
        default=True,
    )
    if not checkUploadConfirm:
        raise typer.Abort()


    cloneConfigurations()
    aggrgateTargetsData(operator_name=operatorName)

    # targets=[{"ip":"192.168.1.21","username":"pi","password":"raspberry","ROS_MASTER_URI":"192.168.1.21","drone_name":"hashimrpi","HEAR_FC":True,"HEAR_MC":True}]
    targets=[{"ip":"10.0.0.55","username":"droneleaf","password":"droneleaf","ROS_MASTER_URI":"http://10.0.0.144:1212/","drone_name":"UAV_1","HEAR_FC":True,"HEAR_MC":True}]
    uav_instance_json_data_stringified['10.0.0.55'] = '{"ip":"10.0.0.119","uri":"https://125.57783.25.55:55","uav_type":"QuadX500_DCDC_NL","actuation_testing":false,"use_ctbr":false,"forward_optitrack_to_px4":true,"en_window_crossing_detection":false,"en_max_tilt_angle":true,"optitrack_rigidbody_id":1,"Description":"ip: must refer to the current host ip, uav_type: used to lookup type settings from UAV_types folder, actuation_testing: use true for direct feed through of actuation commands"}'

    # fileName = "test.sh"

    try:
        # Create a list of asyncio tasks
        tasks = [runTargets(target,filename,uav_instance_json_data_stringified,operator_instance_json_data_stringified) for target in targets]
        asyncio.gather(*tasks)
        print(uav_instance_json_data_stringified)

    except Exception as e :
        print(e)


# sed -i 's/arg name="DRONE_NAME"/arg name="DRONE_NAME"/g'  ~/HEAR_FC/src/HEAR_FC/Flight_controller/launch/flight_controller.launch

# ^\arg name="DRONE_NAME"\s*value="[^\"]*"
# <arg\s*+name="\".*\"\s*"
# ^\<arg name="[DRONE_NAME\"]*"\s*value="[^\"]*"
#         replaceDRONE_NAMECommand = f"if grep -q "['\<arg] name="[DRONE_NAME\"]*"\s*value="[^\"]*"" ~/HEAR_FC/src/HEAR_FC/Flight_controller/launch/flight_controller.launch; then sed -i 's/^\<arg name="['DRONE_NAME\"]*"\s*value="[^\"]*"/\ROS_MASTER_URI={target_ip}/' .bashrc && source ~/.bashrc; else echo 'ROS_MASTER_URI={target_ip}' >> ~/.bashrc && source ~/.bashrc ; fi\n".encode()

@app.callback(invoke_without_command=True)
def callback(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        fleet()


    # if ctx.invoked_subcommand == "fleet":
    #     fleet()
    # elif ctx.invoked_subcommand == "tmp":
    #     tmp()



if __name__ == "__main__":
    app()