#!/bin/bash

ROS_MASTER_URI=$1
# fix slashes
ROS_MASTER_URI_modified=$(echo $ROS_MASTER_URI | sed 's/\//\\\//g')

if grep -q ROS_MASTER_URI ~/.bashrc; then sed -i "s/^\(export\s*ROS_MASTER_URI\s*=\s*\).*$/\export ROS_MASTER_URI=$ROS_MASTER_URI_modified/" ~/.bashrc && source ~/.bashrc; else echo "export ROS_MASTER_URI=$ROS_MASTER_URI" >> ~/.bashrc && source ~/.bashrc ; fi