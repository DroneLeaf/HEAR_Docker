#!/bin/bash

LOCAL_SERVER_API_URI=$1
# fix slashes
LOCAL_SERVER_API_URI_modified=$(echo $LOCAL_SERVER_API_URI | sed 's/\//\\\//g')

if grep -q LOCAL_SERVER_API_URI ~/.bashrc; then sed -i "s/^\(export\s*LOCAL_SERVER_API_URI\s*=\s*\).*$/\export LOCAL_SERVER_API_URI=$LOCAL_SERVER_API_URI_modified/" ~/.bashrc && source ~/.bashrc; else echo "export LOCAL_SERVER_API_URI=$LOCAL_SERVER_API_URI" >> ~/.bashrc && source ~/.bashrc ; fi