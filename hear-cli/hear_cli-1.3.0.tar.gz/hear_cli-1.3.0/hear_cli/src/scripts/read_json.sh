#!/bin/bash

uav_instance_json_data_stringified=$1
operator_instance_json_data_stringified=$2
# fix slashes
# ip= echo "$json" | jq -r '.ip'
ip=$(jq -r '.ip' <<< "$uav_instance_json_data_stringified")
echo "$ip"
# ip=$(echo "$json" | jq -r '.ip')

ros_master_uri=$(jq -r '.ros_master_uri' <<< "$operator_instance_json_data_stringified")
echo "$ros_master_uri"

