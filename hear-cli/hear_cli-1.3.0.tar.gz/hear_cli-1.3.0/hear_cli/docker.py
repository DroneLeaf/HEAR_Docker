import typer
from typing_extensions import Annotated
from InquirerPy import prompt
from enum import Enum
import json
import subprocess
from rich.prompt import Confirm
from rich.prompt import Prompt

import hear_cli.data as data
import hear_cli.utils as utils

app = typer.Typer(help="All docker operations for targets",rich_markup_mode="rich",epilog="Made with :heart:  by [bold blue]Hashim[/bold blue] [bold green]@ DroneLeaf[/bold green]")



module_list_question = questions = [
    {
        "type": "list",
        "name": "target",
        "message": "Select your target: ",
        "choices": data.target_choices
    }
]
def validate_GITHUB_TOKEN(data):
    if data == "" :
        return False
    return True
@app.command("build")
def build():
    """
    [bold violet]Target docker build for docker Cross Compilation[/bold violet] :boom:  :boom: :sparkles:

    """
    target = ""
    GITHUB_ID = ""
    GITHUB_TOKEN = ""
    WS_NAME = ""
    USERNAME = utils.getSystemUserName()

    # get and save target
    if utils.isTargetSeted(data.TargetConfigKeys.docker_target.name):
        target = utils.getTarget(data.TargetConfigKeys.docker_target.name)
        print(target)
    else:
        target = utils.chooseTarget()
        utils.saveTarget(target,data.TargetConfigKeys.docker_target.name)


    # get and save ws_name
    if utils.getValueByKey(data.ConfigKeys.WS_NAME.name) is None:
        WS_NAME = utils.chooseDevWsName()
        utils.saveValueByKey(WS_NAME,data.ConfigKeys.WS_NAME.name)
    else:
        WS_NAME = utils.getValueByKey(data.ConfigKeys.WS_NAME.name)


    # get and save GITHUB_ID
    if utils.getValueByKey(data.ConfigKeys.GITHUB_ID.name) is None:
        GITHUB_ID = Prompt.ask("Enter your GITHUB_ID :sunglasses:")
        utils.saveValueByKey(GITHUB_ID,data.ConfigKeys.GITHUB_ID.name)
    else:
        GITHUB_ID = utils.getValueByKey(data.ConfigKeys.GITHUB_ID.name)

    print(WS_NAME)


    # get and save GITHUB_TOKEN
    if utils.getValueByKey(data.ConfigKeys.GITHUB_TOKEN.name) is None:
        # GITHUB_TOKEN = Prompt.ask("Enter your GITHUB_TOKEN :sunglasses:")
        # GITHUB_TOKEN = typer.prompt('Password', confirmation_prompt=True, hide_input=True)
        questions = [
            {
                'type': 'password',
                'name': 'GITHUB_TOKEN',
                'message': 'Enter your GITHUB_TOKEN',
                'validate':validate_GITHUB_TOKEN
            }
        ]

        answers = prompt(questions)
        GITHUB_TOKEN = answers["GITHUB_TOKEN"]

        utils.saveValueByKey(GITHUB_TOKEN,data.ConfigKeys.GITHUB_TOKEN.name)
    else:
        GITHUB_TOKEN = utils.getValueByKey(data.ConfigKeys.GITHUB_TOKEN.name)



    if target == data.Targets.ORIN.name:
        checkUploadConfirm = Confirm.ask(
            ":star2: Are you sure you want to make full system installation on ORIN target? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()


        build_command = f'docker build --platform=linux/arm64 --progress=plain --build-arg GITHUB_ID="{GITHUB_ID}" --build-arg GITHUB_TOKEN="{GITHUB_TOKEN}" --build-arg TARGET_ORIN="ON" --build-arg opencv_url="geohashim/opencv:4.0.0" --build-arg qt_url="geohashim/qt" --build-arg USERNAME="{USERNAME}" --build-arg WS_NAME={WS_NAME} -t fc_orin .'

        subprocess.run(
            [
                "bash",
                "-c",
                build_command
            ]
        )
    elif target == data.Targets.RPI.name:
        checkUploadConfirm = Confirm.ask(
            ":star2: Are you sure you want to make full system installation on RPI target? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        build_command = f'docker build --platform=linux/arm64 --progress=plain --build-arg GITHUB_ID="{GITHUB_ID}" --build-arg GITHUB_TOKEN="{GITHUB_TOKEN}" --build-arg TARGET_RPI="ON" --build-arg USERNAME="pi" --build-arg WS_NAME={WS_NAME} -t fc_rpi .'

        subprocess.run(
            [
                "bash",
                "-c",
                build_command
            ]
        )

    elif target == data.Targets.SITL.name:
        checkUploadConfirm = Confirm.ask(
            ":star2: Are you sure you want to make full system installation on SITL target? :sunglasses:",
            default=True,
        )
        if not checkUploadConfirm:
            raise typer.Abort()

        build_command = f'docker build --platform=linux/amd64 --progress=plain --build-arg GITHUB_ID="{GITHUB_ID}" --build-arg GITHUB_TOKEN="{GITHUB_TOKEN}" --build-arg TARGET_UBUNTU="ON" --build-arg opencv_url="geohashim/opencv:4.0.0" --build-arg qt_url="geohashim/qt" --build-arg USERNAME="{USERNAME}" --build-arg WS_NAME={WS_NAME} -t fc_sitl .'

        subprocess.run(
            [
                "bash",
                "-c",
                build_command
            ]
        )
    else:
        sys.exit("Error happened, please refer this to hashim")
    # subprocess.run(['bash', '-c','pushd src/targets/SITL_UBUNTU20;sudo ./full_system_installation.sh; popd'])



@app.command("run")
def run():
    """
    [bold violet]Docker run builded image and start dev workspace[/bold violet] :boom:  :boom: :sparkles:

    """
    target = ""
    WS_NAME = ""
    run_command = ""

    if utils.isTargetSeted(data.TargetConfigKeys.docker_target.name):
        target = utils.getTarget(data.TargetConfigKeys.docker_target.name)
        print(target)
    else:
        target = utils.chooseTarget()
        utils.saveTarget(target,data.TargetConfigKeys.docker_target.name)

    # get and save ws_name
    if utils.getValueByKey(data.ConfigKeys.WS_NAME.name) is None:
        WS_NAME = utils.chooseDevWsName()
        utils.saveValueByKey(WS_NAME,data.ConfigKeys.WS_NAME.name)
    else:
        WS_NAME = utils.getValueByKey(data.ConfigKeys.WS_NAME.name)

    if WS_NAME == data.Workspaces.HEAR_FC.name:
        run_command = f'docker run -it -d fc_{target.lower()} --entrypoint bash'
    elif WS_NAME == data.Workspaces. HEAR_MC.name:
        run_command = f'docker run -it -d mc_{target.lower()} --entrypoint bash'



    subprocess.run(
        [
            "bash",
            "-c",
            run_command
        ]
    )




@app.command("pull")
def pull():
    """
    [bold violet]Docker pull pre builded docker image for specific target[/bold violet] :boom:  :boom: :sparkles:

    """

    target = ""
    WS_NAME = ""
    run_command = ""
    run_command4 = ""
    run_command5 = ""
    run_comm2 = ""
    run_comm3 = ""

    if utils.isTargetSeted(data.TargetConfigKeys.docker_target.name):
        target = utils.getTarget(data.TargetConfigKeys.docker_target.name)
        print(target)
    else:
        target = utils.chooseTarget()
        utils.saveTarget(target,data.TargetConfigKeys.docker_target.name)

    # get and save ws_name
    if utils.getValueByKey(data.ConfigKeys.WS_NAME.name) is None:
        WS_NAME = utils.chooseDevWsName()
        utils.saveValueByKey(WS_NAME,data.ConfigKeys.WS_NAME.name)
    else:
        WS_NAME = utils.getValueByKey(data.ConfigKeys.WS_NAME.name)

    if WS_NAME == data.Workspaces.HEAR_FC.name:
        run_command = f'sudo apt  install awscli -y && aws configure set aws_access_key_id "AKIAUJ6SOV74AAMHJYHS" --profile ecrpush && aws configure set aws_secret_access_key "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" --profile ecrpush && aws configure set region "me-south-1" --profile ecrpush && aws ecr get-login-password --region me-south-1 --profile ecrpush | docker login --username AWS --password-stdin 296257236984.dkr.ecr.me-south-1.amazonaws.com'
        run_comm2 = f"docker pull 296257236984.dkr.ecr.me-south-1.amazonaws.com/hear_fc_{target.lower()}:latest"
        run_comm3 = f"docker tag  296257236984.dkr.ecr.me-south-1.amazonaws.com/hear_fc_{target.lower()}:latest fc_{target.lower()}:latest"
    elif WS_NAME == data.Workspaces.HEAR_MC.name:
        run_command = f'sudo apt  install awscli -y && aws configure set aws_access_key_id "AKIAUJ6SOV74AAMHJYHS" --profile ecrpush && aws configure set aws_secret_access_key "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" --profile ecrpush && aws configure set region "me-south-1" --profile ecrpush && aws ecr get-login-password --region me-south-1 --profile ecrpush | docker login --username AWS --password-stdin 296257236984.dkr.ecr.me-south-1.amazonaws.com'
        run_comm2 = f"docker pull 296257236984.dkr.ecr.me-south-1.amazonaws.com/hear_mc_{target.lower()}:latest"
        run_comm3 = f"docker tag  296257236984.dkr.ecr.me-south-1.amazonaws.com/hear_mc_{target.lower()}:latest mc_{target.lower()}:latest"


    print(run_command)
    subprocess.run(
        [
            "bash",
            "-c",
            run_command
        ]
    )

    subprocess.run(
        [
            "bash",
            "-c",
            run_comm2
        ]
    )
    subprocess.run(
        [
            "bash",
            "-c",
            run_comm3
        ]
    )


@app.command("configure")
def configure():
    """
    [bold violet]Update current command saved arguments that already been set[/bold violet] :boom:  :boom: :sparkles:

    """

    config_need = ""
    specific_config_need = ""
    config_need = utils.chooseConfigureCommand()

    if config_need == data.configure_choicesKeys['Set all configs'].name:
        set_WS_NAME(True)
        set_docker_target(True)
        set_GITHUB_ID(True)
        set_GITHUB_TOKEN(True)

        print(config_need)
    elif config_need == data.configure_choicesKeys['Set specific config'].name:
        print(config_need)
        specific_config_need = utils.chooseDockerConfigureSpecificCommand()
        if specific_config_need == data.ConfigKeys.docker_target.name:
            set_docker_target(True)

        elif specific_config_need == data.ConfigKeys.GITHUB_ID.name:
            set_GITHUB_ID(True)

        elif specific_config_need == data.ConfigKeys.GITHUB_TOKEN.name:
            set_GITHUB_TOKEN(True)

        elif specific_config_need == data.ConfigKeys.WS_NAME.name:
            set_WS_NAME(True)




def set_docker_target(mandatory=False):
    target=''
    # get and save docker_target
    if (mandatory is False) and utils.isTargetSeted(data.TargetConfigKeys.docker_target.name):
        target = utils.getTarget(data.TargetConfigKeys.docker_target.name)
        print(target)
    else:
        target = utils.chooseTarget()
        utils.saveTarget(target,data.TargetConfigKeys.docker_target.name)

    return target




def set_GITHUB_ID(mandatory=False):
    GITHUB_ID = ''
    # get and save GITHUB_ID
    if (mandatory is True) or utils.getValueByKey(data.ConfigKeys.GITHUB_ID.name) is None:
        GITHUB_ID = Prompt.ask("Enter your GITHUB_ID :sunglasses:")
        utils.saveValueByKey(GITHUB_ID,data.ConfigKeys.GITHUB_ID.name)
    else:
        GITHUB_ID = utils.getValueByKey(data.ConfigKeys.GITHUB_ID.name)

    return GITHUB_ID


def set_GITHUB_TOKEN(mandatory=False):
    # get and save GITHUB_TOKEN
    if (mandatory is True) or utils.getValueByKey(data.ConfigKeys.GITHUB_TOKEN.name) is None:
        # GITHUB_TOKEN = Prompt.ask("Enter your GITHUB_TOKEN :sunglasses:")
        # GITHUB_TOKEN = typer.prompt('Password', confirmation_prompt=True, hide_input=True)
        questions = [
            {
                'type': 'password',
                'name': 'GITHUB_TOKEN',
                'message': 'Enter your GITHUB_TOKEN',
                'validate':validate_GITHUB_TOKEN
            }
        ]

        answers = prompt(questions)
        GITHUB_TOKEN = answers["GITHUB_TOKEN"]

        utils.saveValueByKey(GITHUB_TOKEN,data.ConfigKeys.GITHUB_TOKEN.name)
    else:
        GITHUB_TOKEN = utils.getValueByKey(data.ConfigKeys.GITHUB_TOKEN.name)


    return GITHUB_TOKEN


def set_WS_NAME(mandatory=False):
    WS_NAME=''
    # get and save ws_name
    if (mandatory is True) or utils.getValueByKey(data.ConfigKeys.WS_NAME.name) is None:
        WS_NAME = utils.chooseDevWsName()
        utils.saveValueByKey(WS_NAME,data.ConfigKeys.WS_NAME.name)
    else:
        WS_NAME = utils.getValueByKey(data.ConfigKeys.WS_NAME.name)

    return WS_NAME








@app.callback()
def callback():
    pass



if __name__ == "__main__":
    app()