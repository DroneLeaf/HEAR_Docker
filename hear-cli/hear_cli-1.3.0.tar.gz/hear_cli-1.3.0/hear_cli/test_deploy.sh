#!/bin/bash

ROS_MASTER_URI=$1
# fix slashes
ls
