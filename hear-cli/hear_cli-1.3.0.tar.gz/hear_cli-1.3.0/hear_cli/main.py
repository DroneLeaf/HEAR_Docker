import typer
import subprocess
# from InquirerPy import prompt
from rich import print as rprint
from typing_extensions import Annotated
from rich.prompt import Prompt
from rich.prompt import Confirm
import hear_cli.target as target
import hear_cli.dev as dev
import hear_cli.fleet as fleet



##
##upload
import sys
import boto3

import os
import threading


from botocore.exceptions import NoCredentialsError, ClientError
import os
import progressbar
import time
from progressbar import ProgressBar, Percentage, \
    Timer, ETA, Counter,Bar

AWS_S3_BUCKET_NAME = 'hear-bucket'
AWS_REGION = 'me-south-1'
AWS_ACCESS_KEY = 'AKIAUJ6SOV74EPNOMEGF'
AWS_SECRET_KEY = '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'
##
app = typer.Typer(help="Welcome to DroneLeaf CLI. Here you can upload files to server and more",rich_markup_mode="rich",epilog="Made with :heart:  by [bold blue]Hashim[/bold blue] [bold green]@ DroneLeaf[/bold green]")
app.add_typer(target.app, name="target")
app.add_typer(dev.app, name="dev")
app.add_typer(fleet.app, name="fleet")



def valid_filetype(file_name):
	# validate file type
	return file_name.endswith('.zip')


def valid_extension(file_name):
	# validate file extension s3Upload.zip
    if (not os.path.splitext(file_name)[1]):
      raise typer.BadParameter("please enter a valid filename, EX file.zip")
      
    return file_name

def valid_path(path):
	# validate file path
     if not os.path.exists(path):
        raise typer.BadParameter("please enter a valid file path")
     
     return path


def uploadCallback():
    rprint("[green bold]start uploading process [green bold]" """\
                                                                  
    ,---,.   ,---,.   ,---,.   ,---,. 
  ,'  .' | ,'  .' | ,'  .' | ,'  .' | 
,---.'   ,---.'   ,---.'   ,---.'   , 
|   |    |   |    |   |    |   |    | 
:   :  .':   :  .':   :  .':   :  .'  
:   |.'  :   |.'  :   |.'  :   |.'    
`---'    `---'    `---'    `---'      
 :arrow_down_small: :arrow_down_small: :arrow_down_small:                                                              
""")




@app.command("upload",epilog="Made with :heart:  by [blue]Hashim[/blue]")
def upload(
           filepath: Annotated[str, typer.Option(help="localfile path",metavar="path/hear_fc_devel.zip",prompt="Enter local file path",callback=valid_path)],
           remote_filename: Annotated[str, typer.Option(help="remote file name",metavar="hear_fc_hashim.zip",prompt="Enter Remote filename",callback=valid_extension)]):
    """
    [bold violet]Upload file to aws s3[/bold violet] :boom:  :boom: , with a [italic]--filepath[/italic] and [italic]--remotefilename[/italic] options. :sparkles:

    """
    NAME_FOR_S3 = 'hear_arch/'+remote_filename

    # print(filepath)
    # print(remote_filename)
    checkUploadConfirm = Confirm.ask(":star2: Are you sure you want to upload the file? :sunglasses:",default=True)
    if not checkUploadConfirm:
        raise typer.Abort()
    uploadToS3(filepath,NAME_FOR_S3)
    rprint('[green bold]File Upload Successfully[/green bold] 👍 :smiley:')
    rprint('[yellow bold] ----- Download url =>[/yellow bold] [violet bold] https://hear-bucket.s3.me-south-1.amazonaws.com/'+NAME_FOR_S3 +' ---- [/violet bold]')


def uploadToS3(LOCAL_FILE,NAME_FOR_S3):    
    # init s3_client
    s3_client = boto3.client(
        service_name='s3',
        region_name=AWS_REGION,
        aws_access_key_id=AWS_ACCESS_KEY,
        aws_secret_access_key=AWS_SECRET_KEY
    )
    
    # define proggress bar
    statinfo = os.stat(LOCAL_FILE)
    widgets = [Percentage()," | ",Timer(), " ",Bar('*'),ETA()]
    up_progress = progressbar.progressbar.ProgressBar(maxval=statinfo.st_size,widgets=widgets)
    up_progress.start()
    def upload_progress(chunk):
       up_progress.update(up_progress.currval + chunk)

    # start upload
    response = s3_client.upload_file(LOCAL_FILE, AWS_S3_BUCKET_NAME, NAME_FOR_S3,
    Callback=upload_progress)
    up_progress.finish()

  
@app.callback(invoke_without_command=True)
def callback(ctx: typer.Context):
    """
    Manage user inputs.
    """
    if ctx.invoked_subcommand is None:
        rprint("[green bold]Welcome to [green bold]" """\

 ___                              _                      ___     ___    _      
(  _`\                           ( )                   /'___)   (  _`\ (_ )  _ 
| | ) | _ __   _     ___     __  | |       __     _ _ | (__     | ( (_) | | (_)
| | | )( '__)/'_`\ /' _ `\ /'__`\| |  _  /'__`\ /'_` )| ,__)    | |  _  | | | |
| |_) || |  ( (_) )| ( ) |(  ___/| |_( )(  ___/( (_| || |       | (_( ) | | | |
(____/'(_)  `\___/'(_) (_)`\____)(____/'`\____)`\__,_)(_)       (____/'(___)(_)
                                                                               
                                                             
                                                               
""")
        #rprint("[yellow]Usage:[/yellow] [violet bold]hear-cli upload[/violet bold]")
        rprint("[yellow]Try with[/yellow] [red bold]--help[/red bold] for help.")
        
    if ctx.invoked_subcommand == "upload":
            uploadCallback()

    #print(f"About to execute command: {ctx.invoked_subcommand}")

if __name__ == "__main__":
    app()    